#!/bin/bash
# Copyright (c) Meta Platforms, Inc. and affiliates. All Rights Reserved.

INPUT_FILE=${INPUT_FILE:-./narrations_v2_7-27-21.json}
VID_ROOT=${VID_ROOT:-~/ego4d}

export $INPUT_FILE

