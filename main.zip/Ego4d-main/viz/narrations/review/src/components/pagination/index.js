// Copyright (c) Meta Platforms, Inc. and affiliates. All Rights Reserved.

import Pagination from "./Pagination";

export { Pagination };
