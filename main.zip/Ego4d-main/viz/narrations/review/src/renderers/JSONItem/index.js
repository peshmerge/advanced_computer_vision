// Copyright (c) Meta Platforms, Inc. and affiliates. All Rights Reserved.

import { JSONItem } from "./JSONItem";

export { JSONItem };
